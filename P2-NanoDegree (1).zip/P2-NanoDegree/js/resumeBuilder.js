var bio = {
    "name": "Mitchell Wong",
    "role": "Supreme Commander of Software Engineering",
    "contacts": {
        "email": "mwong153@gmail.com",
        "github": "mitcho426",
        "location": "San Francisco, CA, United States"
    },
    "picture": "images/me.png",
    "welcomeMessage": "Welcome to my resume built entirely of Javascript!",
    "skills": ["Java", "Javascript", "HTML/CSS", "QA"]
};

var work = {
    "jobs": [{
        "employer": "Salesforce",
        "title": "Software Engineer Intern",
        "location": "San Francisco, CA, United States",
        "datesWorked": "August 2015 - January 2015",
        "description": "Programmed automation tests in Java for newly fixed bugs. Created detailed test cases and performed manual testing on Salesforce Dashboard's interface/functions accordingly. Ran over 10+ weekly automation tests through Selenium F-test console to maintain the quality of regressions.",
        "URL": "http://www.salesforce.com/"
    }, {
        "employer": "The San Francisco Sock Market",
        "title": "Senior Stores Operations",
        "location": "San Francisco, CA, United States",
        "datesWorked": "March 2012 - March 2015",
        "description": "The front runner of all aspects of store management, including inventory, processing transactions, and the POS system to increase store productivity. Responisble for training 3+ new hires, and maintaining steady purchasing terms with business representatives lowering purchasing price up to 25%.",
        "URL": "http://www.sockmarket.com/cgi-local/webstore/shop.cgi?c=start.htm&t=main.blank.htm&storeid=1"
    }]
};

var projects = {
    "projects": [{
        "title": "First Website ever Made",
        "datesWorked": "August 2015",
        "description": "Created my first website that has my professional bio, hobbies, and javascript color changer",
        "url": "http://www.yubaweb.org/mwong/"
    }]
};

var education = {
    "schools": [{
        "name": "City College of San Francisco",
        "datesAttended": "July 2011 - Present",
        "location": "San Francisco, CA, United States",
        "major": "Computer Science",
        "url": "http://www.ccsf.edu/"
    }, {
        "name": "Foothill College",
        "datesAttended": "March 2015 - January 2015",
        "location": "Los Altos Hills, CA, United States",
        "major": "Computer Science",
        "url": "http://www.foothill.edu/index.php"
    }],
    "onlineCourses": [{
        "school": "Udacity",
        "title": "Front-End Web Developmer Nanodegree",
        "completed": "March 2016",
        "url": "https://www.udacity.com/course/front-end-web-developer-nanodegree--nd001"
    }, {
        "school": "Udacity",
        "title": "Intro to Computer Science",
        "completed": "March 2016",
        "url": "https://www.udacity.com/course/intro-to-computer-science--cs101"
    }, {
        "school": "Udacity",
        "title": "Javascript Basics",
        "completed": "March 2016",
        "url": "https://www.udacity.com/course/javascript-basics--ud804"
    }]
};

var formattedName = HTMLheaderName.replace("%data%", bio.name);
var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
var formattedPicture = HTMLbioPic.replace("%data%", bio.picture);
var formattedWelcomeMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);

var formattedContactInfo = [];
formattedContactInfo.push(HTMLemail.replace("%data%", bio.contacts.email));
formattedContactInfo.push(HTMLgithub.replace("%data%", bio.contacts.github));
formattedContactInfo.push(HTMLlocation.replace("%data%", bio.contacts.location));

$("#header").prepend(formattedRole);
$("#header").prepend(formattedName);
$("#header").append(formattedPicture);
$("#header").append(formattedWelcomeMsg);



if (bio.skills.length > 0) {
    $("#header").append(HTMLskillsStart);

    for (var i in bio.skills) {
        $("#header").append(HTMLskills.replace("%data%", bio.skills[i]));
    }
}

for (var i in formattedContactInfo) {
    $("#topContacts").append(formattedContactInfo[i]);
    $("#footerContacts").append(formattedContactInfo[i]);
}


function displayWork() {

    if (work.jobs.length > 0) {
        $("#workExperience").append(HTMLworkStart);

        for (var i in work.jobs) {
            var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[i].employer).replace("#", work.jobs[i].URL);
            var formattedWorkTitle = HTMLworkTitle.replace("%data%", work.jobs[i].title);
            var formattedWorkLocation = HTMLworkLocation.replace("%data%", work.jobs[i].location);
            var formattedDatesWorked = HTMLworkDates.replace("%data%", work.jobs[i].datesWorked);
            var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[i].description);

            var formattedEmployerWorkTitle = formattedEmployer + formattedWorkTitle;

            $(".work-entry").append(formattedEmployerWorkTitle);
            $(".work-entry").append(formattedWorkLocation);
            $(".work-entry").append(formattedDatesWorked);
            $(".work-entry").append(formattedDescription);
        }
    }
}

displayWork();

function displayProjects() {
    $("#projects").append(HTMLprojectStart);
    if (projects.projects.length > 0) {
        for (var i in projects.projects) {
            var formattedProjectTitle = HTMLprojectTitle.replace("%data%", projects.projects[i].title).replace("#", projects.projects[i].url);
            var formattedProjectDates = HTMLprojectDates.replace("%data%", projects.projects[i].datesWorked);
            var formattedProjectDescription = HTMLprojectDescription.replace("%data%", projects.projects[i].description);

            $(".project-entry").append(formattedProjectTitle);
            $(".project-entry").append(formattedProjectDates);
            $(".project-entry").append(formattedProjectDescription);
        }
    }
}

displayProjects();

function displayEducation() {
    $("#education").append(HTMLschoolStart);
    if (education.schools.length > 0 || education.onlineCourses.length > 0) {
        for (var i in education.schools) {
            var formattedSchoolName = HTMLschoolName.replace("%data%", education.schools[i].name).replace("#", education.schools[i].url);
            var formattedSchoolDate = HTMLschoolDates.replace("%data%", education.schools[i].datesAttended);
            var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", education.schools[i].location);
            var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", education.schools[i].major);

            $(".education-entry").append(formattedSchoolName);
            $(".education-entry").append(formattedSchoolDate);
            $(".education-entry").append(formattedSchoolLocation);
            $(".education-entry").append(formattedSchoolMajor);
        }

        $("#education").append(HTMLonlineClasses);
        $("#education").append(HTMLschoolStart);

        for (i in education.onlineCourses) {

            var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", education.onlineCourses[i].title).replace("#", education.onlineCourses[i].url);
            var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[i].school);
            var formattedOnlineCompleted = HTMLonlineDates.replace("%data%", education.onlineCourses[i].completed);
            var formattedOnlineURL = HTMLonlineURL.replace("%data%", "");
            var formattedSchoolTitle = formattedOnlineTitle + formattedOnlineSchool;

            $(".education-entry:last").append(formattedSchoolTitle);
            $(".education-entry:last").append(formattedOnlineCompleted);
            $(".education-entry:last").append(formattedOnlineURL);
        }
    }
}

displayEducation();

$("#mapDiv").append(googleMap);